import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ChatScreen } from '../screens/ChatScreen';

// モバイル版のみ React Navigation を使用
const Stack = createNativeStackNavigator();

export const Navigation: React.FC = () => (
  <NavigationContainer>
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Chat" component={ChatScreen} />
      {/* 他の画面もここに追加可能 */}
    </Stack.Navigator>
  </NavigationContainer>
);
