// src/navigation/index.web.tsx
import React, { useState } from 'react';
import { View, TouchableOpacity, Animated } from 'react-native';
import { Sidebar } from '../components/layout/Sidebar';
import { ChatScreen } from '../screens/ChatScreen';

export const Navigation: React.FC = () => {
  const [isCollapsed, setIsCollapsed] = useState(true); // 初期状態を閉じた状態に
  const [rotateValue] = useState(new Animated.Value(0));

  const toggleSidebar = () => {
    // サイドバー開閉
    setIsCollapsed(!isCollapsed);
    
    // アイコン回転アニメーション
    Animated.timing(rotateValue, {
      toValue: isCollapsed ? 1 : 0,
      duration: 300,
      useNativeDriver: true,
    }).start();
  };

  const rotateInterpolate = rotateValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '90deg'],
  });

  return (
    <View style={{ flex: 1, flexDirection: 'row' }}>
      {/* ハンバーガーアイコン（固定位置） */}
      <TouchableOpacity
        onPress={toggleSidebar}
        style={{
          position: 'absolute',
          top: 20,
          left: isCollapsed ? 20 : 300, // サイドバーの状態に応じて位置調整
          zIndex: 1000,
          width: 40,
          height: 40,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'rgba(0,0,0,0.1)',
          borderRadius: 8,
        }}
      >
        <Animated.Text 
          style={{ 
            fontSize: 20, 
            transform: [{ rotate: rotateInterpolate }] 
          }}
        >
          ☰
        </Animated.Text>
      </TouchableOpacity>

      {/* サイドバー */}
      {!isCollapsed && (
        <View style={{ width: 280 }}>
          <Sidebar
            isCollapsed={isCollapsed}
            onToggle={toggleSidebar}
          />
        </View>
      )}

      {/* メインコンテンツ */}
      <View style={{ 
        flex: 1, 
        marginLeft: isCollapsed ? 0 : 280, // サイドバーが開いている時はマージンを追加
      }}>
        <ChatScreen />
      </View>
    </View>
  );
};
